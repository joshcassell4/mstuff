MESSAGES = {
    'default': 'Hello to the World of Flask!',
}
THINGCOLLECTION = {
    'default': 'This is the default value.'
}

