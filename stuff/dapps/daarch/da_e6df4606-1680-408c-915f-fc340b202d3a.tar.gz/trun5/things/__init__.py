from flask import Flask
from things.things.views import things_blueprint
app = Flask(__name__)
app.register_blueprint(things_blueprint)