#from things import Thing
from things.thing import Thing

# PRODUCTS = {
#     'iphone': {
#         'name': 'iPhone 5S',
#         'category': 'Phones',
#         'price': 699,
#     },
#     'galaxy': {
#         'name': 'Samsung Galaxy 5',
#         'category': 'Phones',
#         'price': 649,
#     },
#     'ipad-air': {
#         'name': 'iPad Air',
#         'category': 'Tablets',
#         'price': 649,
#     },
#     'ipad-mini': {
#         'name': 'iPad Mini',
#         'category': 'Tablets',
#         'price': 549
#     }
# }

ts = [Thing(x,name="thing" + str(x)) for x in range(100)]

THINGS = ts