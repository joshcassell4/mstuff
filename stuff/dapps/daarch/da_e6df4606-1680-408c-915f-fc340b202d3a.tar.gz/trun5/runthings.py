from things import app
app.env="development"
app.run(debug=True,host='0.0.0.0')
